import UIKit

func removeEvenLength (list : [String]) -> [String] {
    var onlyEvens: [String] = []
    for i in 0..<list.count {
        let temp: String = list[i]
        if temp.count % 2 != 0 {
            onlyEvens.append(temp)
        }
    }
return onlyEvens
}

var randomStrings: [String] = []
randomStrings.append("apple")
randomStrings.append("watermelon")
randomStrings.append("plum")
randomStrings.append("strawberry")
randomStrings.append("grape🍇")
print(randomStrings)

let newList: [String] = removeEvenLength(list: randomStrings)
print(newList)
