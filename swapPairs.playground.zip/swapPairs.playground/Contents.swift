func swapPairs(_ arrayList: inout [Int]) {
    for i in 0..<arrayList.count - 1 {
        if i % 2 == 0 {
            let temp = arrayList[i]
            arrayList[i] = arrayList[i + 1]
            arrayList[i + 1] = temp
        }
    }
}

var arrayList: [Int] = []

for _ in 0..<10 {
    arrayList.append(Int.random(in: 0..<100))
}

print("Default List:", arrayList)

// Use the & Symbol to modify without returning in fuction
swapPairs(&arrayList)

print("Modified List:", arrayList)
